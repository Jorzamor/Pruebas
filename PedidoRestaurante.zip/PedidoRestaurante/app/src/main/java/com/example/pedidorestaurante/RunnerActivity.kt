package com.example.pedidorestaurante

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.benchmark.perfetto.Row
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.pedidorestaurante.ui.theme.PedidoRestauranteTheme

class RunnerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PedidoRestauranteTheme {
                    ListarPedidos()
                }
            }
        }

    @Composable
    fun ListarPedidos(){
        var listadePedido: List <PedidoG?> by remember { mutableStateOf(emptyList())}
        var pedidos = MutableListOf<PedidoG?>()

        val TAG = "Lista de Pedidos"
        val database = Firebase.database
        val myRef = database.getReference("pedidog")
        myRef.addValueEventListener(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot){
                val value = snapshot.children
                for (data in value){
                    val PedidoG = data.getValue(PedidoG::class.java)
                    if (PedidoG?.status == "Terminado"){
                        Log.d(TAG,PedidoG.mesa + " " + PedidoG.pedido)
                        pedidos.add(PedidoG)
                    }
                }
                listadePedido = pedidos
                mostrarPedidos(listadePedido)
            }
        })
    }

    @Composable
    fun mostrarPedidos(lista: List<PedidoG?>){
        LazyColumn(){
            items(lista.size){
                var op = lista[indice]

                Row(){
                    Text(""+op?.mesa)
                    Text(""+op?.pedido)
                    Button(onClick = {
                        op?.id?.let { id -> cambiarEstado(id) }}){
                        Text(text = "Entregado")
                    }
                }
            }
        }
    }
}


