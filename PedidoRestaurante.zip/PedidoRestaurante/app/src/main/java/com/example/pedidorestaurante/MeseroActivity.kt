package com.example.pedidorestaurante

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerIcon.Companion.Text
import androidx.compose.ui.semantics.Role.Companion.Button
import com.example.pedidorestaurante.ui.theme.PedidoRestauranteTheme


class MeseroActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PedidoRestauranteTheme {
                CrearOrden()
            }
        }
    }


    @Composable
    fun CrearOrden() {
        var mesa by remember { mutableStateOf("") }
        var pedido by remember { mutableStateOf("") }
        Column() {
            Text("Mesa")
            BasicTextField(
                value = mesa,
                onValueChange = { mesa = it }
            )
            Text("Pedido")
            BasicTextField(
                value = pedido,
                onValueChange = { pedido = it }
            )
            Button(
                onClick = {
                    var pedidoG = PedidoG()
                    PedidoG.mesa = mesa
                    PedidoG.pedido = pedido
                    PedidoG.status = "Procesando"

                    val database = Firebase.database
                    val myRef = database.getReference("pedidog")

                    myRef.child(PedidoG.hashCode().toString()).setValue(PedidoG)
                    mesa = ""
                    pedido = ""
                }){
                Text (text = "Ordenar")
            }
                }
            )
        }
    }
}