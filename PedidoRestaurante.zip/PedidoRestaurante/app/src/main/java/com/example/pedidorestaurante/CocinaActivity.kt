package com.example.pedidorestaurante

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import com.example.pedidorestaurante.ui.theme.PedidoRestauranteTheme

class CocinaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PedidoRestauranteTheme {


                }
            }
        }

@Composable
fun ListarPedidos(){
    var listadePedido: List <PedidoG?> by remember { mutableStateOf(emptyList())}
    var pedidos = MutableListOf<PedidoG?>()

    val TAG = "Lista de Pedidos"
    val database = Firebase.database
    val myRef = database.getReference("pedidog")
    myRef.addValueEventListener(object: ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot){
            val value = snapshot.children
            for (data in value){
                val PedidoG = data.getValue(PedidoG::class.java)
                if (PedidoG?.status == "Procesando"){
                    Log.d(TAG,PedidoG.mesa + " " + PedidoG.pedido)
                    pedidos.add(PedidoG)
                }
            }
            listadePedido = pedidos
            mostrarPedidos(listadePedido)
        }
    })
}

    @Composable
    fun mostrarPedidos(lista: List<PedidoG?>){
        LazyuColumn(){
            items(lista.size){
                var op = lista[indice]
                Row(){
                    Text(""+op?.mesa)
                    Text(""+op?.pedido)
                    Button(onClick = {
                        op?.id?.let { id -> cambiarEstado(id) }}){
                        Text(text = "Entregado")
                    }
                    })
                }
            }
        }
    fun cambiarEstado(id: String){
        val database = Firebase.database
        val myRef = database.getReference("pedidog").child(id)
        myRef.child("status").setValue("Entregado").addOnSuccessListener {
            Log.d(TAG, "Estado cambiado a Entregado para el objeto con ID: $id")}
            .addOnFailureListener {Log.e(TAG, "Error al cambiar el estado del objeto con ID: $id", it)}
        }
    }


