package com.example.pedidorestaurante;

public class PedidoG {
    var mesa: String = ""
    var pedido: String = ""
    var status: String = ""
}
