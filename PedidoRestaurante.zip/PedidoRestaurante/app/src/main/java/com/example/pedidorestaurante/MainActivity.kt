package com.example.pedidorestaurante

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role.Companion.Button
import androidx.compose.ui.tooling.preview.Preview
import com.example.pedidorestaurante.ui.theme.PedidoRestauranteTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PedidoRestauranteTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                            name = "Android",
                            modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }


@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Column() {
        Button(onClick = {
            val intent = Intent(this@MainActivity, MeseroActivity::class.java)
            startActivity(intent)
        }){Text("Mesero")}
        Button(onClick = {
            var intent = Intent(this@MainActivity, CocinaActivity::class.java)
            startActivity(intent)
        } ){Text("Cocina")}
        Button( onClick = {
            var intent = Intent(this@MainActivity, RunnerActivity::class.java)
            startActivity(intent)
        }){Text("Runner")}
    }

}



@Composable
fun GreetingPreview() {
    PedidoRestauranteTheme {
        Greeting("Android")
    }
}
}